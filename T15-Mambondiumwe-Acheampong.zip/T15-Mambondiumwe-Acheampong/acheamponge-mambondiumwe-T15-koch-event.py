
# T15- Interactive Graphics
# Objectives: Work with Events in Python.
# Acknowledgements: 
'''
Koch curve code modified  by Dr. Jan Pearce
from http://openbookproject.net/thinkcs/python/english3e/recursion.html
'''
# xfoto.gif obtained from omer-ogd.deviantart.com/art/grey-minimal-273522059
# licensed under a Creative Commons
# Attribution-Noncommercial-Share Alike 3.0 United States License.
#
# Team members:
# Acheamponge
# Mambondiumwea

import turtle
import Tkinter
import random

class Koch:
    '''class draws Koch curves and Koch snowflakes'''
    def __init__(self, order=3, size=200, x=-250, y=0, r=0, g=0, b=0):
        ''' '''
        self.order = order
        self.size = size
        self.x = x
        self.y = y
        self.turtle = turtle.Turtle()
        self.turtle.color(r, g, b)
        self.moveto()

     

    def moveto(self):
        self.turtle.penup()
        self.turtle.goto(self.x,self.y)
        self.turtle.pendown()

  
        
    def draw_koch(self, t, neworder, newsize):
        '''This draws the Koch Curve, a fractal that starts with a line that is then
        subdivided into 3 equal parts, and the subparts are then drawn recursively.'''
        if neworder == 0: # base case
            t.forward(newsize)
        else:
            for angle in [60, -120, 60, 0]:
               self.draw_koch(t, neworder-1, newsize/3)
               t.left(angle)

    def snowflake(self):
        """Draws a Koch snowflake (a triangle with a Koch curve for each side)."""
        for i in range(3):
            self.draw_koch(self.turtle, self.order, self.size)
            self.turtle.right(120)

def main():
    ''' the main function sets up a window and beings
    the Koch curve of order given by the order.'''
    wn=turtle.Screen()
    wn.colormode(255)
    wn.bgcolor("coral")
    wn.title("Koch Snowflakes")
    adwa=turtle.Turtle()
    adwa.up()
    adwa.setpos(210, 250)
    adwa.down()
    adwa.write("Created by Andrew & Emmanuel", move = False , align = 'center' , font = ("Arial", 12,("bold", "normal")))
    adwa.hideturtle()

    adwa.up()
    adwa.setpos(-150, 245)
    adwa.down()
    adwa.write("CLICK ANYWHERE", move=False, align='center', font=("Arial", 20, ("bold", "normal")))
    adwa.hideturtle()

    wn.register_shape("xfoto.gif")
    adwa.up()
    adwa.setpos(0, -100)
    adwa.down()
    adwa.shape("xfoto.gif")
    adwa.stamp()
    
    def handler_goto(x, y):
        k=Koch(random.randrange(4), random.randrange(100)+50, x, y,random.randrange(255), random.randrange(255), random.randrange(255))
        k.snowflake()
   
    
    # Event handler for the q button on the keyboard
    def handler_quitit():
        wn.bye()        # Closes the window

    
    
    wn.onclick(handler_goto) 
    
    # Calls the event handler quitit() for onkey events for "q"
    wn.onkey(handler_quitit, "q")

   # NOTICE that the screen is responding to the click events
           # Wire up a click on the window.
    wn.listen()
    Tkinter.mainloop()              # wn.exitonclick() no longer works because we want to have an onclick event!
                                    # Replaced the wn.mainloop() method call which does not exist
                                    # in Python version 2.7 with the appropriate one in the
                                    # Tkinter module.
main()