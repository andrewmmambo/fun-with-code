######################################################################
# A flawed birthday program
#
# Author: Jan Pearce
# username: Navigator-Marima Mambondiumwe. Driver-Bryce Carlberg
#
# Purpose: This program has flow of control, parameter-passing, and 
#          other structural problems which need to be fixed.
######################################################################
# Acknowledgements:Dr Jan Pearce

######################################################################

def happyBirthday(name, x):                             #replaced i with name,i was an invalid parameter name as i represents something in the python library   #This defines the function
    '''says a Happy birthday message '''
    for i in range(x):
        print("Happy Birthday to you!")
    print("Happy Birthday, dear " + name + ".")         #replaced i with name
    print("Happy Birthday to you!")

def main():                                             #this defines the main function
    happyBirthday('Felix Heggen', 4)                    # name and number of times to loop             #this calls the happy birthday function within the main function

main()                                                  #this calls the main function

