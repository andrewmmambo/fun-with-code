######################################################################
# A flawed program which uses a function to determine the area of a circle

# Author: Jan Pearce
#
##Driver-Marima Mambondiumwe Navigator-Bryce Carlberg
#
# Background:
# The area of a circle is the number of square units inside that circle.
# a formula for this area is a = PI * r**2 where PI is an irrational number
# approximated by PI=3.141592

# Purpose
# To learn to debug programs with flow-of control and parameter passing problems
# There are several problems.
######################################################################
# Acknowledgements:
#Dr Jan Pearce
######################################################################
import sys                                                      #this imports system module


def testit(did_pass):                                           #This defines the function
    """ Print the result of a unit test. """
    linenum = sys._getframe(1).f_lineno                         # Get the caller's line number.
    if did_pass:
        msg = "Test at line {0} ok.".format(linenum)
    else:
        msg = ("Test at line {0} FAILED.".format(linenum))
    print(msg)

def circleArea(r):                                              #removed i as the paremeter and replaced it with r
    '''this calculates the area of the circle'''
    PI = 3.141592                                               #removed i=r completely.this was bad code
    area = PI * r**2                                            # this formula is correct
    return area

def circleArea_test_suite():                                    # this defines the function
    """this function carries out a test suite on the coding"""
    print("\nRunning circleArea_test_suite()).")
    testit(circleArea(0)==0)                                    #this starts a series of tests on the code
    testit(circleArea(1)==3.141592)
    testit(circleArea(2.5)==3.141592*2.5*2.5)

def main():                                                     #this defines the main function .This is where the main program starts
    r=int(raw_input('please enter desired radius: '))           #i put int() to correct the bug.the rwa input was being taken as a string and not an integer
    circleArea(r)
    print("The area is: " + str(circleArea(r)))
    circleArea_test_suite()

main()                                                          #this calls the main function